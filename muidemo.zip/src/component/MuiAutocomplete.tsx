import { Stack,Autocomplete, TextField } from '@mui/material'
import React from 'react'
const skills = ['HTML','CSS','JAVASCRIPT','TYPESCRIPT','REACT']
export const MuiAutocomplete = () => {
  return (
        <Stack spacing={2} width='250px'>
           
        </Stack>
  )
}
